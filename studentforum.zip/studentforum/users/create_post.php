<?php
session_start();
require '../models/dbConnect.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];

// Fetch all posts from the database
$stmt = $pdo->query("SELECT * FROM modules");
$modules = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aliens | New Post</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/post-style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container">
    <?php
    include '../components/header.php'
    ?>
    <div class="post-container">
        <h1>Create A New Post</h1>
        <form method="POST" action="../functions/create_post_action.php" enctype="multipart/form-data">
            <label for="title">Title: </label>
            <input type="text-post" name="title" id="title" placeholder="Enter the post title" required>
            
            <label for="content">Content: </label>
            <textarea name="content" id="content" placeholder="Enter the post content" required></textarea>  

            <label for="module_id">Module: </label>
            <select name="module_id" id="module_id" required="">
                <?php foreach ($modules as $module): ?>
                    <option value="<?php echo $module['module_id'] ?>">
                        <?php echo htmlspecialchars($module['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <label for="image">Upload Image:</label> 
            <input type="file" name="image" id="image" value="Choose Image">
            <button type="submit" class="form-button">Create Question</button>
        </form>
        <a href="home.php" class="back-button">Back to Home</a>
    </div>
</body>
</html>
