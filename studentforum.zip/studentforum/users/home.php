<?php
session_start();
require '../models/dbConnect.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];

// Fetch all posts from the database
$stmt = $pdo->query("SELECT posts.post_id, posts.title, posts.created_at, posts.updated_at, posts.user_id, users.name AS name 
                     FROM posts 
                     JOIN users ON posts.user_id = users.user_id 
                     ORDER BY posts.created_at DESC");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | User Home</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/user-style.css">
    <link rel="stylesheet" href="../css/logo-style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <?php
        include '../components/header.php'
        ?>
        <div class="user-container">
            <div class="title-container">
                <img src="../assets/Logo.webp" class="logo-title">
                <div>
                    Welcome to
                    <h1 class="form-title">Aliens,
                        <?php echo htmlspecialchars($user['name']); ?>!
                    </h1>
                </div>
            </div>

            <fieldset class="user-container">
                <legend><h3>User Profile</h3></legend>
                <p>
                    <b>Username: </b>
                    <?php echo htmlspecialchars($user['name']); ?>
                </p>
                <p>
                    <b>Email: </b>
                    <?php echo htmlspecialchars($user['email']); ?>
                </p>
                <p>
                    <b>Created date: </b>
                    <?php echo date("d/m/Y", strtotime($user['created_at'])); ?>
                </p>
                <div class="button-nav-container">
                    <a href="create_post.php">Create post</a>
                    <a href="edit_profile.php">Edit profile</a>
                    <a href="mailto:poisiedon14@gmail.com">Contact Admin</a>
                    <a href="../functions/logout.php">Log Out</a>
                </div>
            </fieldset>

            <fieldset class="allposts-container">
                <legend><h3>All Posts</h3></legend>
                <?php foreach ($posts as $post):
                    $post_id = $post['post_id'];
                ?>
                    <fieldset class="posts-container" id="post-<?php echo $post_id; ?>">
                        <legend><h3>
                            <a href="view_post.php?post_id=<?php echo $post_id; ?>">
                                <?php echo htmlspecialchars($post['title']); ?>
                            </a>
                        </h3></legend>    
                        <p>
                            <b>Posted by: </b>
                            <?php echo htmlspecialchars($post['name']); ?>
                        </p>
                        <p>
                            <b>Posted on: </b>
                            <?php echo date("d/m/Y, H:i", strtotime($post['created_at'])); ?>
                        </p>
                        <?php if (!empty($post['updated_at'])): ?>
                            <p>
                                <b>Updated on: </b>
                                <?php echo date("d/m/Y, H:i", strtotime($post['updated_at'])); ?>
                            </p>
                        <?php endif; ?>
                        <!-- Check if the logged-in user is the creator of the post -->
                        <?php if ($user['user_id'] === $post['user_id']): ?>
                            <div class="button-nav-container">
                                <a href="../edit/edit_post.php?post_id=<?php echo $post_id; ?>">Edit</a>
                                <a href="../functions/delete_post.php?post_id=<?php echo $post_id; ?>" onclick="return confirm('Are you sure you want to delete this post?');">Delete</a>
                            </div>
                        <?php endif; ?>
                    </fieldset>
                <?php endforeach; ?>
            </fieldset>

            <div class="posts">
                
                
            </div>
        </div>
    </div>
</body>
</html>
