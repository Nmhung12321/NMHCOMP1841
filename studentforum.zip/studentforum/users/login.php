<?php
session_start();
if (isset($_SESSION['errors'])) {
    $errors = $_SESSION['errors'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | User Log In</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/user-style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <div class="container">
        <?php
        include '../components/header.php'
        ?>
        <div class="user-container">
            <div class="profile-check" id="signIn">
                <?php
                include '../components/welcome_logo.php'
                ?>
                <form method="POST" action="../functions/user-account.php">
                    <h2>Log In to your account!</h2>
                    <?php
                    if (isset($errors['login'])) {
                        echo '<div class="error-main">
                                <p>' . $errors['login'] . '</p>
                              </div>';
                        unset($errors['login']);
                    }
                    ?>
                    <div class="input-group">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" id="email" placeholder="Enter your Email" required>
                        
                    </div>
                    <div class="input-group password">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" id="password" placeholder="Enter your Password" required>
                        <i id="eye" class="fa fa-eye"></i>
                        <?php
                        if (isset($errors['password'])) {
                            echo ' <div class="error">
                                    <p>' . $errors['password'] . '</p>
                                </div>';
                        }
                        ?>
                    </div>
                    <button type="submit" class="form-button" name="login">Log In</button>
                </form>

                <div class="links">
                    <p>Don't have an account? </p>
                    <a href="register.php">Create Account</a>
                </div>
            </div>
        </div>
    </div>
        <script>
        const eyeIcon = document.getElementById("eye");
        const passwordField = document.getElementById("password");
        eyeIcon.addEventListener('click', () => {
            if (passwordField.type === "password" && passwordField.value) {
                passwordField.type = "text";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            }   
        });
    </script>
</body>

</html>
<?php
if (isset($_SESSION['errors'])) {
    unset($_SESSION['errors']);
}
?>
