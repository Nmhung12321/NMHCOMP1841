<?php

session_start();
if (isset($_SESSION['errors'])) {
    $errors = $_SESSION['errors'];
 }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | User Register</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/user-style.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../js/script.js"></script>
</head>

<body>
    <div class="container">
        <?php
        include '../components/header.php'
        ?>
        <div class="user-container">
            <div class="profile-check" id="signup">
                <?php
                include '../components/welcome_logo.php'
                ?>
                <form method="POST" action="../functions/user-account.php">
                    <h2>Register your account!</h2>
                    <?php
                    if (isset($errors['user_exist'])) {
                        echo '<div class="error-main">
                                <p>' . $errors['user_exist'] . '</p>
                            </div>';
                        unset($errors['user_exist']);
                    }
                    ?>
                    <div class="input-group">
                        <i class="fas fa-user"></i>
                        <input type="text" name="name" id="name" placeholder="Enter your Username" required>
                        <?php
                        if (isset($errors['name'])){
                            echo ' <div class="error">
                                    <p>' . $errors['name'] . '</p>
                                </div>';
                        }
                        ?>
                    </div>
                    <div class="input-group">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" id="email" placeholder="Enter your Email" required>
                        <?php
                        if (isset($errors['email'])) {
                            echo '<div class="error">
                                    <p>' . $errors['email'] . '</p>
                                </div>';
                            unset($errors['email']);
                        }
                        ?>
                    </div>
                    <div class="input-group password">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" id="password" placeholder="Make your Password" >
                        <i id="eye" class="fa fa-eye"></i>
                        <?php
                        if (isset($errors['password'])) {
                            echo '<div class="error">
                                    <p>' . $errors['password'] . '</p>
                                </div>';
                            unset($errors['password']);
                        }
                        ?>
                    </div>
                    <div class="input-group password">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="confirm_password" placeholder="Confirm your Password" required>
                        <i id="eye" class="fa fa-eye"></i>
                        <?php
                        if (isset($errors['confirm_password'])) {
                            echo '<div class="error">
                                    <p>' . $errors['confirm_password'] . '</p>
                                </div>';
                            unset($errors['confirm_password']);
                        }
                        ?>
                    </div>
                    <button type="submit" class="form-button" value="Create Account" name="signup">Sign Up</button>
                </form>
            </div>
            <div class="links">
                <p>Already Have An Account?</p>
                <a href="login.php">Log In</a>
            </div>
        </div>
    </div>
</body>

</html>
<?php
if(isset($_SESSION['errors'])){
unset($_SESSION['errors']);
}
?>