<?php
session_start();
require '../models/dbConnect.php';

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: /index.php");
    exit();
}

// Initialize variables
$post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : null;

// If post_id is invalid, exit
if (!$post_id) {
    echo "No post ID provided.";
    exit();
}

// Handle the comment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    $comment = trim($_POST['comment']);
    $user_id = $_SESSION['user']['user_id']; // Logged-in user ID
    $name = $_SESSION['user']['name'] ?? 'Anonymous'; // User's name or 'Anonymous'

    if (!empty($comment)) {
        $stmt = $pdo->prepare("
            INSERT INTO comments (post_id, user_id, name, comment, created_at) 
            VALUES (:post_id, :user_id, :name, :comment, NOW())
        ");
        $stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':name', $name, PDO::PARAM_STR);
        $stmt->bindParam(':comment', $comment, PDO::PARAM_STR);

        if ($stmt->execute()) {
            // Redirect to avoid resubmission
            header("Location: view_post.php?post_id=$post_id");
            exit();
        } else {
            echo "Failed to post your comment. Please try again.";
        }
    } else {
        echo "Comment cannot be empty.";
    }
}

// Fetch the post, user, and module data
$stmt = $pdo->prepare("
    SELECT posts.*, users.name AS user_name, modules.name AS module_name 
    FROM posts 
    LEFT JOIN users ON posts.user_id = users.user_id 
    LEFT JOIN modules ON posts.module_id = modules.module_id 
    WHERE posts.post_id = :post_id
");
$stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
$stmt->execute();
$post = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$post) {
    echo "No results found.";
    exit();
}

// Fetch comments for this post
$comments_stmt = $pdo->prepare("
    SELECT comments.comment, comments.created_at, IFNULL(users.name, 'Anonymous') AS user_name 
    FROM comments 
    LEFT JOIN users ON comments.user_id = users.user_id 
    WHERE comments.post_id = :post_id 
    ORDER BY comments.created_at DESC
");
$comments_stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
$comments_stmt->execute();
$comments = $comments_stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aliens | View Post</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/post-style.css">
    <link rel="stylesheet" href="../css/style.css">
    
</head>
<body>
<div class="container">
    <?php
    include '../components/header.php'
    ?>
    <div class="post-container">
        <h1>
            <?php echo htmlspecialchars($post['title']); ?>
        </h1>
        <p>
            <b>Posted by: </b>
            <?php echo htmlspecialchars($post['user_name']); ?>
        </p>
        <p>
            <b>Module:</b>
            <?php echo htmlspecialchars($post['module_name']); ?>
        </p>
        <p>
            <b>Posted on: </b>
            <?php echo date("F j, Y, g:i a", strtotime($post['created_at'])); ?>
        </p>
        <p><b>Content:</b></p>
        <div class="post-content">
            <p>
                <?php echo nl2br(htmlspecialchars($post['content'])); ?>
            </p>
            <?php if (!empty($post['image'])): ?>
                <div class="post-image">
                    <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="Post Image">
                </div>
            <?php endif; ?>
        </div>

        <form method="POST" action="">
            <h2>Share your view:</h2>
            <textarea name="comment" id="comment" required></textarea>
            <button type="submit" class="form-button">Share your thought!</button>
        </form>

        <fieldset class="comments-container">
            <legend><h3>Comments:</h3></legend>
            <?php if ($comments): ?>
            <?php foreach ($comments as $comment): ?>
                <div class="comment-container">
                    <p><b>
                        <?php echo htmlspecialchars($comment['user_name']); ?>
                    </b></p>
                    <p class="comment">
                        <?php  echo nl2br(htmlspecialchars($comment['comment'])); ?>
                    </p>
                    <p class="comment-date">
                        <?php echo date("F j, Y, g:i a", strtotime($comment['created_at'])); ?>
                    </p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Let's be the earliest person to leave a comment!</p>
        <?php endif; ?>
        </fieldset>

        <a href="home.php" class="back-button">Back to Dashboard</a>
    </div>
</div>
</body>
</html>
