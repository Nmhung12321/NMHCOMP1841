<?php
session_start();
require '../models/dbConnect.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

try {
    // Fetch all users
    $stmt = $pdo->query("SELECT user_id, name, email, created_at FROM users ORDER BY created_at DESC");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | Manage Users</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link rel="stylesheet" href="../css/admin-style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <?php
        include '../components/header.php'
        ?>
        <div class="admin-container">
            <div class="admin-title">
                <h1>Manage Users</h1>
            </div>
            <a href="add_user.php" class="add-button">Add New User</a>
            <fieldset>
                <legend><h2>List users</h2></legend>
                <ul>
                    <?php foreach ($users as $user): ?>
                        <li class="posts-container">
                            <div class="admin-title">
                                <h3><?= htmlspecialchars($user['name']) ?> (<?= htmlspecialchars($user['email']) ?>)</h3>
                            </div>
                            <p>
                                <b>Registered At:</b> <?= htmlspecialchars($user['created_at']) ?>
                            </p>
                            <div class="post-nav-container">
                                <a href="edit_user.php?user_id=<?= $user['user_id'] ?>">Edit</a>
                                <a href="/functions/delete_user.php?user_id=<?= $user['user_id'] ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </fieldset>
            <a href="admin_dashboard.php" class="back-button">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
