<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | Admin Dashboard</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link rel="stylesheet" href="../css/admin-style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <?php
        include '../components/header.php'
        ?>
        <div class="admin-container">
            <div class="admin-title">
                <h1>Admin Dashboard</h1>
                <h2>Manage Site Content</h2>
            </div>
            <ul class="management-nav">
                <li><a href="manage_posts.php">Manage Posts</a></li>
                <li><a href="manage_users.php">Manage Users</a></li>
                <li><a href="manage_modules.php">Manage Modules</a></li>
            </ul>
            <a href="../functions/logout.php" class="back-button">Logout</a>
        </div>
    </div>
</body>
</html>
