<?php
session_start();
require '../models/dbConnect.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

try {
    // Fetch all posts with user and module details
    $stmt = $pdo->query("SELECT posts.post_id, posts.title, posts.content, posts.created_at, users.name AS user_name, modules.name AS module_name
                         FROM posts
                         LEFT JOIN users ON posts.user_id = users.user_id
                         LEFT JOIN modules ON posts.module_id = modules.module_id
                         ORDER BY posts.created_at DESC");
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | Manage Posts</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link rel="stylesheet" href="../css/admin-style.css">
    <link rel="stylesheet" href="../css/style.css">
    <script>
        function deletePost(postId) {
            if (confirm("Are you sure you want to delete this post?")) {
                fetch(`/functions/delete_post.php?post_id=${postId}`, {
                    method: 'GET',
                })
                .then(response => response.text())
                .then(message => {
                    alert(message); // Alert the response message
                    if (message === "Post deleted successfully.") {
                        document.getElementById(`post-${postId}`).remove(); // Remove the post from DOM
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred. Please try again.");
                });
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <?php
        include '../components/header.php'
        ?>
        <div class="admin-container">
            <div class="admin-title">
                <h1>Manage Posts</h1>
            </div>
            <a href="add_post.php" class="add-button">Add New Post</a>
            <fieldset>
                <legend><h2>List posts</h2></legend>
                <ul>
                    <?php foreach ($posts as $post): ?>
                        <li class="posts-container" id="post-<?= $post['post_id'] ?>">
                            <div class="admin-title">
                                <h2><?= htmlspecialchars($post['title']) ?></h2>
                            </div>
                            <p>
                                <b>Author:</b> <?= htmlspecialchars($post['user_name']) ?>
                            </p>
                            <p>
                                <b>Module:</b> <?= htmlspecialchars($post['module_name']) ?>
                            </p>
                            <p>
                                <b>Created At:</b> <?= htmlspecialchars($post['created_at']) ?>
                            </p>
                            <p>
                                <b>Content:</b><br><?= nl2br(htmlspecialchars($post['content'])) ?>
                            </p>
                            <div class="post-nav-container">
                                <a href="../edit/edit_post.php?post_id=<?= $post['post_id'] ?>">Edit</a>
                                <a href="javascript:void(0);" onclick="deletePost(<?= $post['post_id'] ?>)">Delete</a>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </fieldset>
            
            <a href="admin_dashboard.php" class="back-button">Back to admin dashboard</a>
        </div>
    </div>
</body>
</html>
