<?php
session_start();
require '../models/dbConnect.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

try {
    if (isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);

        // Fetch the user data
        $stmt = $pdo->prepare("SELECT user_id, name, email FROM users WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            die("User not found!");
        }

        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);

            if ($name && $email) {
                $updateStmt = $pdo->prepare("UPDATE users SET name = ?, email = ? WHERE user_id = ?");
                $updateStmt->execute([$name, $email, $user_id]);

                header("Location: manage_users.php");
                exit();
            } else {
                $error = "Please fill in all fields.";
            }
        }
    } else {
        die("Invalid user ID.");
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | Edit user</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link rel="stylesheet" href="../css/post-style.css">
    <link rel="stylesheet" href="../css/admin-style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <?php
        include '../components/header.php'
        ?>
        <div class="post-container">
            <div class="admin-title">
                <h1>Edit User</h1>
            </div>
            <?php if (isset($error)): ?>
                <p class="error"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>
            <form method="POST">
                <label for="name">Name:</label>
                <input type="text-post" id="name" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                <button type="submit" class="form-button">Save Changes</button>
            </form>
            <a href="manage_users.php" class="back-button">Back to Manage Users</a>
        </div>
    </div>
</body>
</html>
