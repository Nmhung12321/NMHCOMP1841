<?php
session_start();
require '../models/dbConnect.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

try {
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $moduleName = trim($_POST['module_name']);

        // Check if the module name is not empty
        if (empty($moduleName)) {
            $error = "Module name cannot be empty.";
        } else {
            // Insert the new module into the database
            $stmt = $pdo->prepare("INSERT INTO modules (name) VALUES (:name)");
            $stmt->execute(['name' => $moduleName]);

            // Redirect to the dashboard
            header('Location: admin_dashboard.php');
            exit();
        }
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | Add Module</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link rel="stylesheet" href="../css/post-style.css">
    <link rel="stylesheet" href="../css/admin-style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <?php
        include '../components/header.php'
        ?>
        <div class="post-container">
            <div class="admin-title">
                <h1>Add New Module</h1>
            </div>
            <?php if (isset($error)): ?>
                <p class="error"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>
            <form method="post" action="">
                <label for="module_name">Module Name:</label>
                <input type="text-post" id="module_name" name="module_name" required>
                <button type="submit" class="form-button">Add Module</button>
            </form>
            <a href="manage_modules.php" class="back-button">Back to manage module</a>
        </div>
    </div>
</body>
</html>
