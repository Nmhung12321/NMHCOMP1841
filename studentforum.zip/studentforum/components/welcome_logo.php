<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aliens | Welcome!</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/logo-style.css">
</head>

<body>
    <div class="title-container">
        <img src="../assets/Logo.webp" class="logo-title">
        <div>
            Welcome to
            <h1 class="form-title">Aliens!</h1>
        </div>
    </div>
</body>

</html>