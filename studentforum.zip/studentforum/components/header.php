<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/header-style.css">
    <script src="../js/script.js"></script>
</head>

<body>
    <div class="header-container">
        <div class="header">
            <div class="logo-container">
                <img src="../assets/Logo.webp" class="logo">
                <h3>Aliens Forum</h3>
            </div>
            <div class="introduce-container">
                <h3>About ALIENS!</h3>
                <p><b>Aliens</b> is a forum for students at GreenWich University. Here, you'll find a wealth of resources, discussions, and support to help you succeed in your studies. Whether you're seeking help with a challenging assignment, looking for study buddies, or simply want to connect with fellow students, Aliens is the place to be. Join us and become part of our thriving academic community!</p>
                <p class="author">
                    Designed by 
                    <a href="mailto:poisiedon14@gmail.com"> Hung</a>
                </p>
            </div>
            <div class="account-container">
                <button class="avatar" onclick="clickAccountButton()">
                    <i class="fa-solid fa-user fa-xl"></i>
                </button>
                <div class="dropdown-content"   id="account">
                    <a href="../users/login.php">Login</a>
                    <a href="../users/register.php">Register</a>
                </div>
            </div>
        </div>
        <div class="topnav" id="header-topnav">
            <a href="../index.php">Welcome</a>
            <a href="../users/home.php">User</a>
            <a href="../admins/admin_dashboard.php">Admin</a>
            <a href="mailto:poisiedon14@gmail.com">Contact</a> <!-- Use your email -->
            <a href="javascript:void(0);" class="icon" onclick="topNav()">
                <i class="fa fa-bars"></i>
            </a>
        </div>
    </div>
</body>