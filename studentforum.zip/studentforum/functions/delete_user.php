<?php
session_start();
require '../models/dbConnect.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

try {
    if (isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']);

        // Delete the user
        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->execute([$user_id]);

        header("Location: /admins/manage_users.php");
        exit();
    } else {
        die("Invalid user ID.");
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
