<?php
session_start();
require '../models/dbConnect.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

if (!isset($_GET['module_id']) || !is_numeric($_GET['module_id'])) {
    header('Location: manage_modules.php');
    exit();
}

try {
    // Retrieve module ID from the URL
    $module_id = intval($_GET['module_id']);

    // Delete the module
    $stmt = $pdo->prepare("DELETE FROM modules WHERE module_id = :module_id");
    $stmt->bindParam(':module_id', $module_id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        header('Location: /admins/manage_modules.php?message=Module+deleted+successfully');
        exit();
    } else {
        header('Location: /admins/manage_modules.php?error=Unable+to+delete+module');
        exit();
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

